import Image from "next/image";

const About = () => {
  const features = [
    {
      title: "1.Align with curriculum goals",
      description:
        "The selected SDG should align with the science curriculum, building upon existing knowledge and skills.",
    },
    {
      title: "2.Relevance to the local context",
      description:
      "Consider the local environmental, social, and economic challenges related to the chosen SDG.",
    },
    {
      title: "3.Engaging and impactful",
      description:
        "Choose a relevant and engaging SDG for students, fostering curiosity and a sense of purpose.",
    },
    {
      title: "4.Action-oriented",
      description:
        "Select an SDG that allows for practical application, encouraging students to take action and contribute to solutions.",
    },
    {
      title: "5.Cross-curricular connections",
      description:
        "Identify points where the chosen SDG can be integrated into existing science topics, such as climate change within a weather unit, or biodiversity within a biology unit.",
    },
    {
      title: "6.Adapting lesson plans",
      description:
        "Modify existing lesson plans to incorporate SDG perspectives, activities, and discussion points.",
    },
    {
      title: "7.Project-based learning",
      description:
        "Develop project-based learning activities that address the chosen SDG, allowing students to apply their knowledge and skills in a real-world context.",
    },
  ];

  return (
    <section className="text-white body-font">
      <div className="container px-5 py-24 mx-auto flex flex-wrap">
        <div className="lg:w-1/2 w-full mb-10 lg:mb-0 rounded-lg overflow-hidden">
          <Image
            alt="feature"
            src="/about.png"
            width="1000"
            height="1000"
          ></Image>
        </div>
        <div className="flex flex-col flex-wrap lg:py-6 -mb-10 lg:w-1/2 lg:pl-12 lg:text-left text-center">
          {features.map((feature, index) => (
            <div
              className="flex flex-col mb-10 lg:items-start items-center"
              key={index}
            >
              <div className="flex-grow">
                <h2 className="text-white text-xl title-font font-bold mb-3">
                  {feature.title}
                </h2>
                <p className="leading-relaxed text-base">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;