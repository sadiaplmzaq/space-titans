const Foot = () => {
  return (
    <div></div>
  )
}

export default Foot