import Link from "next/link"

const Hero = () => {
  return (
    <div id="hero" className="h-[90vh]">
      <div className="pt-48 py-6">
        <h1 className="text-center font-bold text-4xl">Sustainable Development Goals (SDGs) into Science Education</h1>
        <h3 className="text-center text-xl">Empowering young minds to become agents of change for a sustainable future.</h3>
      </div>
      <div className="flex gap-16 justify-center">
      <Link href="https://forms.gle/KcXRDpXEJPnwwAw46"><button className="btn btn-active w-[8rem] text-white bg-gray-800">Regsiter</button></Link>
      <Link href="/about"><button className="btn btn-active w-[8rem] text-white bg-gray-800">Get Started</button></Link>
      </div>
    </div>
  )
}

export default Hero