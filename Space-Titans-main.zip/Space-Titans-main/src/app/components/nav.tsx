import Link from "next/link";
import Image from "next/image";

const Nav = () => {
  return (
    <header className="bg-[#171717] sticky top-0 z-50 text-gray-600 body-font">
      <div className="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
        <Link href="/" className="flex title-font font-medium items-center text-white mb-4 md:mb-0">
          <Image 
          src="/logo.png"
          width="40"
          height="40"
          alt="logo">
          </Image>
          <span className="ml-3 text-xl">Space Titans</span>
        </Link>
        <nav className="md:ml-auto flex flex-wrap items-center text-base justify-center text-white">
          <Link href="/" className="mr-5 hover:text-gray-400 hover:cursor-pointer">
            Home
          </Link>
          <Link href="/about" className="mr-5 hover:text-gray-400 hover:cursor-pointer">
            About
          </Link>
          <Link href="/learnMore" className="mr-5 hover:text-gray-400 hover:cursor-pointer">
            Learn More
          </Link>
          <Link href="/courses" className="mr-5 hover:text-gray-400 hover:cursor-pointer">
            Courses
          </Link>
          <Link href="/contact" className="mr-5 hover:text-gray-400 hover:cursor-pointer">
            Contact Us
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Nav;
