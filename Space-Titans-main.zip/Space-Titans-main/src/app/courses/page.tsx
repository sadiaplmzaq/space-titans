import Link from 'next/link';

const topics = [
  {
    id: 1,
    title: "Introduction to No Poverty",
    description:
      "This course explores strategies to eliminate poverty worldwide. Topics include poverty measurement, causes and effects, global poverty trends, and successful poverty reduction programs.",
  },
  {
    id: 2,
    title: "Understanding Zero Hunger",
    description:
      "Focused on eradicating hunger, this course covers food security, nutritional requirements, agricultural practices, food distribution systems, and global initiatives to combat hunger.",
  },
  {
    id: 3,
    title: "Good Health and Well-being: Principles and Practices",
    description:
      "Examine strategies for improving health outcomes. Topics include healthcare systems, disease prevention, mental health, nutrition, and global health policies.",
  },
  {
    id: 4,
    title: "Quality Education: Strategies and Solutions",
    description:
      "This course addresses the goal of providing quality education for all. It covers educational methods, curriculum development, educational equity, and innovative teaching practices.",
  },
  {
    id: 5,
    title: "Gender Equality: Concepts and Implementation",
    description:
      "Explore the principles of gender equality. Topics include gender-based disparities, legal frameworks, empowerment strategies, and case studies on achieving gender equality.",
  },
  {
    id: 6,
    title: "Clean Water and Sanitation: Challenges and Innovations",
    description:
      "Learn about providing access to clean water and sanitation. Topics include water purification technologies, sanitation practices, global water scarcity issues, and related health impacts.",
  },
  {
    id: 7,
    title: "Affordable and Clean Energy: Technology and Policy",
    description:
      "Study the transition to sustainable energy solutions. Topics include renewable energy sources, energy efficiency, energy policy, and the impact of energy on economic development.",
  },
  {
    id: 8,
    title: "Decent Work and Economic Growth: Theories and Trends",
    description:
      "This course covers the principles of creating decent work and fostering economic growth. Topics include labor market dynamics, economic policies, job creation strategies, and inclusive growth.",
  },
  {
    id: 9,
    title: "Industry, Innovation, and Infrastructure: Development and Impact",
    description:
      "Explore the role of industry and innovation in economic development. Topics include infrastructure development, technological advancements, industrial policies, and sustainable practices.",
  },
  {
    id: 10,
    title: "Reducing Inequality: Policies and Practices",
    description:
      "Focus on strategies to reduce social and economic inequalities. Topics include income distribution, social justice, anti-discrimination policies, and economic reforms.",
  },
  {
    id: 11,
    title: "Sustainable Cities and Communities: Planning and Development",
    description:
      "Study urban development and sustainability. Topics include smart city planning, sustainable infrastructure, urban resilience, and community engagement in city planning.",
  },
  {
    id: 12,
    title: "Responsible Consumption and Production: Sustainable Practices",
    description:
      "Examine practices for sustainable consumption and production. Topics include waste management, sustainable supply chains, eco-friendly products, and consumer behavior.",
  },
  {
    id: 13,
    title: "Climate Action: Mitigation and Adaptation",
    description:
      "Learn about addressing climate change. Topics include greenhouse gas emissions, climate change mitigation strategies, adaptation measures, and international climate agreements.",
  },
  {
    id: 14,
    title: "Life Below Water: Conservation and Management",
    description:
      "Focus on marine conservation efforts. Topics include ocean ecosystems, marine biodiversity, pollution control, and sustainable fisheries management.",
  },
  {
    id: 15,
    title: "Life on Land: Biodiversity and Ecosystem Management",
    description:
      "Study terrestrial ecosystems and biodiversity conservation. Topics include habitat protection, endangered species, deforestation, and ecosystem services.",
  },
  {
    id: 16,
    title: "Peace, Justice, and Strong Institutions: Governance and Reform",
    description:
      "Explore the foundations of peace and justice. Topics include rule of law, governance structures, conflict resolution, and human rights protection.",
  },
  {
    id: 17,
    title: "Partnerships for the Goals: Collaboration and Strategy",
    description:
      "Learn about building effective partnerships to achieve SDGs. Topics include multi-stakeholder collaboration, international cooperation, resource mobilization, and strategic alliances.",
  },
];

interface StepProps {
  id: number;
  title: string;
  description: string;
}

const TopicCard: React.FC<StepProps> = ({ id, title, description }) => (
    <div className="lg:w-1/4 md:w-1/2 p-4 w-full">
      <div className="flex flex-col h-full border border-gray-300 p-4 rounded-lg">
        <div>
          <h3 className="text-white text-xs tracking-widest title-font mb-1">TOPIC {id}</h3>
          <h2 className="text-white title-font text-lg font-medium">{title}</h2>
        </div>
        <div className="flex-grow mt-2">
          <p className="mt-1">{description}</p>
        </div>
        <div className="mt-4">
          <Link href="https://forms.gle/KcXRDpXEJPnwwAw46">
            <button className="btn btn-active w-[8rem] text-white bg-gray-800 mt-auto">
              Register
            </button>
          </Link>
        </div>
      </div>
    </div>
);
  
const SDGTopics = () => {
  return (
    <section className="text-gray-400 body-font">
      <div className="container px-5 py-24 mx-auto">
        <div className="flex flex-wrap -m-4">
          {topics.map((topic) => (
            <TopicCard
              key={topic.id}
              id={topic.id}
              title={topic.title}
              description={topic.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default SDGTopics;